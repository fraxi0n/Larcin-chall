module.exports = require('./src/PathFinding');
